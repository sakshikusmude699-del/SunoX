package com.soundamplifier.data

import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

class FirestoreUserRepository {

    private val db = FirebaseFirestore.getInstance()

    suspend fun createOrUpdateUserProfile(user: FirebaseUser, language: String) {
        try {
            val uid = user.uid
            val docRef = db.collection(COL_USERS).document(uid)
            val snapshot = docRef.get().await()
            val data = mutableMapOf<String, Any?>(
                KEY_EMAIL to user.email,
                KEY_DISPLAY_NAME to user.displayName,
                KEY_LAST_LOGIN to FieldValue.serverTimestamp(),
                KEY_LANGUAGE to language,
            )
            when {
                !user.phoneNumber.isNullOrBlank() -> data[KEY_PHONE] = user.phoneNumber
                snapshot.exists() -> {
                    val existing = snapshot.get(KEY_PHONE) as? String
                    if (!existing.isNullOrBlank()) data[KEY_PHONE] = existing
                }
            }
            if (!snapshot.exists()) {
                data[KEY_CREATED_AT] = FieldValue.serverTimestamp()
            }
            docRef.set(data, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.e(TAG, "createOrUpdateUserProfile failed", e)
        }
    }

    suspend fun getStoredPhoneNumber(uid: String): String? {
        return try {
            val doc = db.collection(COL_USERS).document(uid).get().await()
            if (!doc.exists()) return null
            when (val p = doc.get(KEY_PHONE)) {
                is String -> p.trim().takeIf { it.isNotEmpty() }
                else -> null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getStoredPhoneNumber failed", e)
            null
        }
    }

    suspend fun shouldCollectPhoneNumber(user: FirebaseUser): Boolean {
        if (!user.phoneNumber.isNullOrBlank()) return false
        val stored = getStoredPhoneNumber(user.uid)
        return stored.isNullOrBlank()
    }

    suspend fun updatePhoneNumber(uid: String, phone: String) {
        val trimmed = phone.trim()
        if (trimmed.isEmpty()) throw IllegalArgumentException("phone empty")
        db.collection(COL_USERS).document(uid).set(
            mapOf(
                KEY_PHONE to trimmed,
                KEY_LAST_LOGIN to FieldValue.serverTimestamp(),
            ),
            SetOptions.merge(),
        ).await()
    }

    suspend fun saveAudiogram(
        uid: String,
        leftEar: Map<String, Int>,
        rightEar: Map<String, Int>,
    ) {
        try {
            val col = db.collection(COL_USERS).document(uid).collection(SUB_AUDIOGRAMS)
            val activeSnap = col.whereEqualTo(KEY_IS_ACTIVE, true).get().await()
            val newRef = col.document()
            val batch = db.batch()
            for (doc in activeSnap.documents) {
                batch.update(doc.reference, KEY_IS_ACTIVE, false)
            }
            batch.set(
                newRef,
                mapOf(
                    KEY_CREATED_AT to FieldValue.serverTimestamp(),
                    KEY_LEFT_EAR to leftEar,
                    KEY_RIGHT_EAR to rightEar,
                    KEY_IS_ACTIVE to true,
                ),
            )
            batch.commit().await()
        } catch (e: Exception) {
            Log.e(TAG, "saveAudiogram failed", e)
        }
    }

    suspend fun getActiveAudiogram(uid: String): Map<String, Any>? {
        return try {
            val col = db.collection(COL_USERS).document(uid).collection(SUB_AUDIOGRAMS)
            val snap = col.whereEqualTo(KEY_IS_ACTIVE, true).limit(1).get().await()
            val doc = snap.documents.firstOrNull() ?: return null
            doc.data
        } catch (e: Exception) {
            Log.e(TAG, "getActiveAudiogram failed", e)
            null
        }
    }

    suspend fun getAllAudiograms(uid: String): List<Map<String, Any>> {
        return try {
            val col = db.collection(COL_USERS).document(uid).collection(SUB_AUDIOGRAMS)
            val snap = col.orderBy(KEY_CREATED_AT, Query.Direction.DESCENDING).get().await()
            snap.documents.mapNotNull { it.data }
        } catch (e: Exception) {
            Log.e(TAG, "getAllAudiograms failed", e)
            emptyList()
        }
    }

    suspend fun saveCustomPreset(uid: String, preset: CustomPreset) {
        try {
            val docId = preset.id.toString()
            val ref = db.collection(COL_USERS).document(uid).collection(SUB_CUSTOM_PRESETS).document(docId)
            ref.set(
                mapOf(
                    KEY_CP_NAME to preset.name,
                    KEY_CP_BOOST to preset.boostQuietSounds,
                    KEY_CP_MASTER to preset.masterGain,
                    KEY_CP_LOW to preset.lowBoostDb,
                    KEY_CP_HIGH to preset.highBoostDb,
                    KEY_CP_CREATED_AT to preset.createdAt,
                ),
            ).await()
        } catch (e: Exception) {
            Log.e(TAG, "saveCustomPreset failed", e)
        }
    }

    suspend fun deleteCustomPreset(uid: String, presetId: Int) {
        try {
            db.collection(COL_USERS).document(uid).collection(SUB_CUSTOM_PRESETS)
                .document(presetId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "deleteCustomPreset failed", e)
        }
    }

    suspend fun getAllCustomPresets(uid: String): List<Map<String, Any>> {
        return try {
            val col = db.collection(COL_USERS).document(uid).collection(SUB_CUSTOM_PRESETS)
            val snap = col.orderBy(KEY_CP_CREATED_AT, Query.Direction.DESCENDING).get().await()
            snap.documents.mapNotNull { doc ->
                val data = doc.data?.toMutableMap() ?: return@mapNotNull null
                data[KEY_ID] = doc.id.toIntOrNull() ?: return@mapNotNull null
                data
            }
        } catch (e: Exception) {
            Log.e(TAG, "getAllCustomPresets failed", e)
            emptyList()
        }
    }

    private companion object {
        const val TAG = "FirestoreRepo"
        const val COL_USERS = "users"
        const val SUB_AUDIOGRAMS = "audiograms"
        const val SUB_CUSTOM_PRESETS = "custom_presets"

        const val KEY_PHONE = "phone"
        const val KEY_EMAIL = "email"
        const val KEY_DISPLAY_NAME = "displayName"
        const val KEY_CREATED_AT = "createdAt"
        const val KEY_LAST_LOGIN = "lastLoginAt"
        const val KEY_LANGUAGE = "language"
        const val KEY_LEFT_EAR = "leftEar"
        const val KEY_RIGHT_EAR = "rightEar"
        const val KEY_IS_ACTIVE = "isActive"

        const val KEY_ID = "id"
        const val KEY_CP_NAME = "name"
        const val KEY_CP_BOOST = "boostQuietSounds"
        const val KEY_CP_MASTER = "masterGain"
        const val KEY_CP_LOW = "lowBoostDb"
        const val KEY_CP_HIGH = "highBoostDb"
        const val KEY_CP_CREATED_AT = "createdAt"
    }
}

/** Build [CustomPreset] from Firestore row (`id` injected from document id in [FirestoreUserRepository.getAllCustomPresets]). */
fun Map<String, Any>.customPresetFromFirestoreMap(): CustomPreset? {
    val id = (this["id"] as? Number)?.toInt() ?: return null
    val name = this["name"] as? String ?: return null
    val boost = (this["boostQuietSounds"] as? Number)?.toFloat() ?: return null
    val master = (this["masterGain"] as? Number)?.toFloat() ?: return null
    val low = (this["lowBoostDb"] as? Number)?.toFloat() ?: return null
    val high = (this["highBoostDb"] as? Number)?.toFloat() ?: return null
    val created = when (val raw = this["createdAt"]) {
        is Timestamp -> raw.toDate().time
        is Number -> raw.toLong()
        else -> System.currentTimeMillis()
    }
    return CustomPreset(
        id = id,
        accountId = AccountLocalIds.GUEST,
        name = name,
        boostQuietSounds = boost,
        masterGain = master,
        lowBoostDb = low,
        highBoostDb = high,
        createdAt = created,
    )
}
