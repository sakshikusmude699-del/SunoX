package com.soundamplifier.auth

sealed class AuthState {
    data object LoggedOut : AuthState()
    data class LoggedIn(
        val displayLabel: String,
        val needsPhoneCapture: Boolean = false,
    ) : AuthState()
    data class Error(val message: String) : AuthState()
}
