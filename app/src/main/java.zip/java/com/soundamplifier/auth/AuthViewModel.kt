package com.soundamplifier.auth

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.soundamplifier.data.AccountLocalIds
import com.soundamplifier.data.CustomPresetDao
import com.soundamplifier.data.FirestoreUserRepository
import com.soundamplifier.data.ProfileRepository
import com.soundamplifier.data.customPresetFromFirestoreMap
import com.soundamplifier.data.firestoreAudiogramMapsMatchDocument
import com.soundamplifier.data.toAudiogramProfileFromFirestore
import com.soundamplifier.data.toFirestoreEarMaps
import com.soundamplifier.ui.LocaleManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private fun FirebaseUser?.displayLabel(): String =
    this?.let { u ->
        u.displayName?.takeIf { it.isNotBlank() }
            ?: u.email?.takeIf { it.isNotBlank() }
            ?: u.phoneNumber?.takeIf { it.isNotBlank() }
            ?: u.uid
    }.orEmpty()

class AuthViewModel(
    private val profileRepository: ProfileRepository,
    private val customPresetDao: CustomPresetDao,
) : ViewModel() {
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestoreUserRepository = FirestoreUserRepository()

    private val _state = MutableStateFlow<AuthState>(AuthState.LoggedOut)
    val state: StateFlow<AuthState> = _state

    init {
        val user = firebaseAuth.currentUser
        if (user != null) {
            _state.value = AuthState.LoggedIn(user.displayLabel(), needsPhoneCapture = false)
            scheduleUserProfileSync(user)
        }
    }

    private fun scheduleUserProfileSync(user: FirebaseUser?) {
        val firebaseUser = user ?: return
        viewModelScope.launch {
            try {
                val context = FirebaseApp.getInstance().applicationContext
                val lang = LocaleManager.getSavedLanguageCode(context)
                firestoreUserRepository.createOrUpdateUserProfile(firebaseUser, lang)
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Firestore profile sync failed", e)
            }
            try {
                mergeAudiogramsAfterLogin(firebaseUser)
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Audiogram cloud merge failed", e)
            }
            try {
                mergeCustomPresetsAfterLogin(firebaseUser)
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Custom preset cloud merge failed", e)
            }
            val needsPhone = try {
                firestoreUserRepository.shouldCollectPhoneNumber(firebaseUser)
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Phone capture check failed", e)
                false
            }
            val cur = _state.value
            if (cur is AuthState.LoggedIn && firebaseAuth.currentUser?.uid == firebaseUser.uid) {
                _state.value = cur.copy(needsPhoneCapture = needsPhone)
            }
        }
    }

    private suspend fun mergeAudiogramsAfterLogin(user: FirebaseUser) {
        val uid = user.uid
        var localUser = profileRepository.getLatestForAccount(uid)
        val localGuest = profileRepository.getLatestForAccount(AccountLocalIds.GUEST)
        val cloudActive = firestoreUserRepository.getActiveAudiogram(uid)

        if (localUser == null && localGuest != null && cloudActive == null) {
            profileRepository.saveProfile(localGuest.copy(id = 0, accountId = uid))
            localUser = profileRepository.getLatestForAccount(uid)
        }

        if (localUser == null && cloudActive != null) {
            val profile = cloudActive.toAudiogramProfileFromFirestore()
            if (profile != null) {
                profileRepository.saveProfile(profile.copy(id = 0, accountId = uid))
            } else {
                Log.w("AuthViewModel", "Active Firestore audiogram could not be parsed for local save")
            }
            return
        }

        if (localUser != null) {
            val (leftMap, rightMap) = localUser.toFirestoreEarMaps()
            val allCloud = firestoreUserRepository.getAllAudiograms(uid)
            val existsOnCloud = allCloud.any { doc ->
                firestoreAudiogramMapsMatchDocument(doc, leftMap, rightMap)
            }
            if (!existsOnCloud) {
                firestoreUserRepository.saveAudiogram(uid, leftMap, rightMap)
            }
        }
    }

    private suspend fun mergeCustomPresetsAfterLogin(user: FirebaseUser) {
        val uid = user.uid
        val remoteRows = firestoreUserRepository.getAllCustomPresets(uid)
        val remotePresets = remoteRows.mapNotNull { row ->
            row.customPresetFromFirestoreMap()?.copy(id = 0, accountId = uid)
        }
        var localList = customPresetDao.getAllPresetsForAccount(uid)

        for (remote in remotePresets) {
            val existsLocally = localList.any { local -> local.sameSignatureAs(remote) }
            if (!existsLocally) {
                customPresetDao.insertOrReplace(remote.copy(id = 0, accountId = uid))
                localList = customPresetDao.getAllPresetsForAccount(uid)
            }
        }

        localList = customPresetDao.getAllPresetsForAccount(uid)
        val refreshedRemote = firestoreUserRepository.getAllCustomPresets(uid)
            .mapNotNull { it.customPresetFromFirestoreMap() }
        for (local in localList) {
            val existsOnRemote = refreshedRemote.any { remote -> remote.sameSignatureAs(local) }
            if (!existsOnRemote) {
                firestoreUserRepository.saveCustomPreset(uid, local)
            }
        }
    }

    fun onGoogleSignInResult(idToken: String?, errorMessage: String? = null) {
        if (idToken.isNullOrBlank()) {
            if (!errorMessage.isNullOrBlank()) {
                _state.value = AuthState.Error(errorMessage)
            }
            return
        }
        viewModelScope.launch {
            try {
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                val result = firebaseAuth.signInWithCredential(credential).await()
                val user = result.user ?: run {
                    _state.value = AuthState.Error("Sign-in failed")
                    return@launch
                }
                val context = FirebaseApp.getInstance().applicationContext
                val lang = LocaleManager.getSavedLanguageCode(context)
                firestoreUserRepository.createOrUpdateUserProfile(user, lang)
                try {
                    mergeAudiogramsAfterLogin(user)
                } catch (e: Exception) {
                    Log.e("AuthViewModel", "Audiogram cloud merge failed", e)
                }
                try {
                    mergeCustomPresetsAfterLogin(user)
                } catch (e: Exception) {
                    Log.e("AuthViewModel", "Custom preset cloud merge failed", e)
                }
                val needsPhone = try {
                    firestoreUserRepository.shouldCollectPhoneNumber(user)
                } catch (e: Exception) {
                    Log.e("AuthViewModel", "Phone capture check failed", e)
                    true
                }
                _state.value = AuthState.LoggedIn(user.displayLabel(), needsPhoneCapture = needsPhone)
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Google sign-in failed", e)
                _state.value = AuthState.Error(e.message ?: "Google sign-in failed")
            }
        }
    }

    fun saveUserPhoneNumber(
        raw: String,
        onInvalid: () -> Unit,
        onError: (String) -> Unit,
    ) {
        val normalized = raw.trim()
        val digitCount = normalized.count { it.isDigit() }
        if (digitCount < 8) {
            onInvalid()
            return
        }
        val user = firebaseAuth.currentUser ?: return
        viewModelScope.launch {
            try {
                firestoreUserRepository.updatePhoneNumber(user.uid, normalized)
                _state.value = AuthState.LoggedIn(user.displayLabel(), needsPhoneCapture = false)
            } catch (e: Exception) {
                Log.e("AuthViewModel", "saveUserPhoneNumber failed", e)
                onError(e.message ?: "Failed to save phone number")
            }
        }
    }

    /** Clears a one-shot error so the UI can toast and reset without sticking in Error state. */
    fun consumeAuthError() {
        if (_state.value is AuthState.Error) {
            _state.value = AuthState.LoggedOut
        }
    }

    fun logout() {
        firebaseAuth.signOut()
        _state.value = AuthState.LoggedOut
    }
}
