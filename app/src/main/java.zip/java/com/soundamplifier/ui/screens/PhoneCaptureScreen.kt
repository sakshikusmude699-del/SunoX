package com.soundamplifier.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundamplifier.R

@Composable
fun PhoneCaptureScreen(
    isDarkMode: Boolean,
    onThemeToggle: () -> Unit,
    onContinue: (String) -> Unit,
    onSignOut: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    var phoneDraft by remember { mutableStateOf("") }
    val isLightBg = scheme.background.luminance() > 0.5f
    val blobPurpleAlpha = if (isLightBg) 0.15f else 0.28f
    val blobLavenderAlpha = if (isLightBg) 0.20f else 0.22f

    BackHandler { /* Block back: require phone or sign out */ }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background),
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp),
        ) {
            IconButton(onClick = onThemeToggle) {
                Icon(
                    imageVector = if (isDarkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                    contentDescription = if (isDarkMode) {
                        stringResource(R.string.theme_light_mode)
                    } else {
                        stringResource(R.string.theme_dark_mode)
                    },
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxSize(0.55f)
                .align(Alignment.TopCenter)
                .clip(CircleShape)
                .blur(80.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            scheme.primary.copy(alpha = blobPurpleAlpha),
                            Color.Transparent,
                        ),
                        radius = 420f,
                        tileMode = TileMode.Clamp,
                    ),
                ),
        )
        Box(
            modifier = Modifier
                .fillMaxSize(0.6f)
                .align(Alignment.BottomCenter)
                .clip(CircleShape)
                .blur(92.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            scheme.secondary.copy(alpha = blobLavenderAlpha),
                            Color.Transparent,
                        ),
                        radius = 460f,
                        tileMode = TileMode.Clamp,
                    ),
                ),
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .padding(top = 56.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = stringResource(R.string.phone_capture_title),
                style = MaterialTheme.typography.headlineSmall,
                color = scheme.onBackground,
                textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.phone_capture_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(28.dp))
            OutlinedTextField(
                value = phoneDraft,
                onValueChange = { phoneDraft = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.phone_capture_label)) },
                placeholder = { Text(stringResource(R.string.phone_capture_hint)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(16.dp),
            )
            Spacer(modifier = Modifier.height(20.dp))
            val shape = RoundedCornerShape(24.dp)
            OutlinedButton(
                onClick = { onContinue(phoneDraft) },
                modifier = Modifier.fillMaxWidth(),
                shape = shape,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = scheme.primary,
                ),
            ) {
                Text(
                    stringResource(R.string.phone_capture_continue),
                    style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 0.5.sp),
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            TextButton(onClick = onSignOut) {
                Text(
                    stringResource(R.string.phone_capture_sign_out),
                    color = scheme.error,
                )
            }
        }
    }
}

fun toastInvalidPhone(context: android.content.Context) {
    Toast.makeText(context, context.getString(R.string.phone_capture_invalid), Toast.LENGTH_SHORT).show()
}
