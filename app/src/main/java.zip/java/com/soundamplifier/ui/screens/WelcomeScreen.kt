package com.soundamplifier.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundamplifier.R

@Composable
fun WelcomeScreen(
    isDarkMode: Boolean = false,
    onThemeToggle: () -> Unit = {},
    onLoginGoogle: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val isLightBg = scheme.background.luminance() > 0.5f
    val blobPurpleAlpha = if (isLightBg) 0.15f else 0.28f
    val blobLavenderAlpha = if (isLightBg) 0.20f else 0.22f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background),
    ) {
        Box(
            modifier = Modifier
                .size(320.dp)
                .offset(x = 220.dp, y = (-80).dp)
                .clip(CircleShape)
                .blur(80.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            scheme.primary.copy(alpha = blobPurpleAlpha),
                            Color.Transparent,
                        ),
                        radius = 380f,
                        tileMode = TileMode.Clamp,
                    ),
                ),
        )
        Box(
            modifier = Modifier
                .size(360.dp)
                .offset(x = (-140).dp, y = 560.dp)
                .clip(CircleShape)
                .blur(92.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            scheme.secondary.copy(alpha = blobLavenderAlpha),
                            Color.Transparent,
                        ),
                        radius = 420f,
                        tileMode = TileMode.Clamp,
                    ),
                ),
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
            ) {
                IconButton(onClick = onThemeToggle) {
                    Icon(
                        imageVector = if (isDarkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                        contentDescription = if (isDarkMode) {
                            stringResource(R.string.theme_light_mode)
                        } else {
                            stringResource(R.string.theme_dark_mode)
                        },
                        tint = scheme.onSurface,
                    )
                }
            }

            val unbounded = FontFamily(
                Font(
                    googleFont = GoogleFont("Unbounded"),
                    fontProvider = GoogleFont.Provider(
                        providerAuthority = "com.google.android.gms.fonts",
                        providerPackage = "com.google.android.gms",
                        certificates = R.array.com_google_android_gms_fonts_certs,
                    ),
                    weight = FontWeight.Bold,
                ),
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.4f),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    val logoBackdrop = colorResource(
                        if (isLightBg) R.color.logo_backdrop_light else R.color.logo_backdrop_dark
                    )
                    Box(
                        modifier = Modifier
                            .size(108.dp)
                            .clip(CircleShape)
                            .background(logoBackdrop),
                        contentAlignment = Alignment.Center,
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.app_logo),
                            contentDescription = stringResource(R.string.cd_app_logo),
                            modifier = Modifier.fillMaxSize(0.76f),
                            contentScale = ContentScale.Fit,
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = stringResource(R.string.welcome_title),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontFamily = unbounded,
                            fontWeight = FontWeight.Bold,
                        ),
                        textAlign = TextAlign.Center,
                        color = scheme.onBackground,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.welcome_tagline),
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            FrostedPillButton(
                text = stringResource(R.string.welcome_login_google),
                onClick = onLoginGoogle,
                modifier = Modifier.fillMaxWidth(),
                leadingContent = {
                    Image(
                        painter = painterResource(R.drawable.ic_logo_google),
                        contentDescription = stringResource(R.string.cd_google_logo),
                        modifier = Modifier.size(22.dp),
                    )
                },
            )

            Spacer(modifier = Modifier.weight(1f))

            Text(
                text = stringResource(R.string.welcome_terms),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                color = scheme.onSurfaceVariant.copy(alpha = 0.85f),
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
            )
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
private fun FrostedPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingContent: (@Composable RowScope.() -> Unit)? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    val borderColor = scheme.outline.copy(alpha = 0.35f)
    val fill = scheme.surface.copy(alpha = if (scheme.background.luminance() > 0.5f) 0.40f else 0.28f)
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = shape,
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = fill),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (leadingContent != null) {
                leadingContent()
                Spacer(modifier = Modifier.width(10.dp))
            }
            Text(
                text = text,
                color = scheme.primary,
                style = MaterialTheme.typography.titleMedium,
            )
        }
    }
}
