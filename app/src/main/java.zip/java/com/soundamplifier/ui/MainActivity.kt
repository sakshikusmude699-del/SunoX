package com.soundamplifier.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import androidx.room.Room
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.soundamplifier.R
import com.soundamplifier.auth.AuthState
import com.soundamplifier.auth.AuthViewModel
import com.soundamplifier.data.AccountLocalIds
import com.soundamplifier.data.AppDatabase
import com.soundamplifier.data.HearingTestPreferences
import com.soundamplifier.data.MIGRATION_2_3
import com.soundamplifier.data.MIGRATION_3_4
import com.soundamplifier.data.ProfileRepository
import com.soundamplifier.ui.screens.AmplifierScreen
import com.soundamplifier.ui.screens.AudiogramScreen
import com.soundamplifier.ui.screens.FaqScreen
import com.soundamplifier.ui.screens.HomeScreen
import com.soundamplifier.ui.screens.ProfileScreen
import com.soundamplifier.ui.screens.SettingsScreen
import com.soundamplifier.ui.screens.PhoneCaptureScreen
import com.soundamplifier.ui.screens.WelcomeScreen
import com.soundamplifier.ui.screens.toastInvalidPhone
import com.soundamplifier.viewmodel.AmplifierViewModel
import com.soundamplifier.viewmodel.AudiogramViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object ThemeManager {
    internal const val PREFS_NAME = "smarthear_prefs"
    private const val KEY_FOLLOW_SYSTEM = "follow_system_theme"
    private const val KEY_DARK_MODE = "dark_mode"
    private const val KEY_GUEST_MODE = "guest_mode"

    private val _followSystem = MutableStateFlow(true)
    private val _explicitDark = MutableStateFlow(false)
    val followSystem: StateFlow<Boolean> = _followSystem.asStateFlow()
    val explicitDark: StateFlow<Boolean> = _explicitDark.asStateFlow()

    fun init(context: android.content.Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
        if (!prefs.contains(KEY_FOLLOW_SYSTEM)) {
            val hadExplicitDark = prefs.getBoolean(KEY_DARK_MODE, false)
            if (hadExplicitDark) {
                prefs.edit().putBoolean(KEY_FOLLOW_SYSTEM, false).apply()
                _followSystem.value = false
                _explicitDark.value = true
            } else {
                prefs.edit().putBoolean(KEY_FOLLOW_SYSTEM, true).apply()
                _followSystem.value = true
                _explicitDark.value = false
            }
        } else {
            _followSystem.value = prefs.getBoolean(KEY_FOLLOW_SYSTEM, true)
            _explicitDark.value = prefs.getBoolean(KEY_DARK_MODE, false)
        }
        if (prefs.contains(KEY_GUEST_MODE)) {
            prefs.edit().remove(KEY_GUEST_MODE).apply()
        }
        syncAppCompatNightMode(context)
    }

    fun syncAppCompatNightMode(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val follow = prefs.getBoolean(KEY_FOLLOW_SYSTEM, true)
        val mode = when {
            follow -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            prefs.getBoolean(KEY_DARK_MODE, false) -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_NO
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    fun clearGuestMode(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .remove(KEY_GUEST_MODE)
            .commit()
    }

    /**
     * Switches to explicit light/dark (stops following system). [currentlyResolvedDark] is the
     * appearance the user sees now (system + preference combined).
     */
    fun toggle(activity: android.app.Activity, currentlyResolvedDark: Boolean) {
        val next = !currentlyResolvedDark
        _followSystem.value = false
        _explicitDark.value = next
        val prefs = activity.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_FOLLOW_SYSTEM, false)
            .putBoolean(KEY_DARK_MODE, next)
            .apply()
        syncAppCompatNightMode(activity)
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var amplifierViewModel: AmplifierViewModel
    private lateinit var audiogramViewModel: AudiogramViewModel
    private lateinit var authViewModel: AuthViewModel
    private lateinit var profileRepository: ProfileRepository

    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* handled silently; UI will show error if mic unavailable */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.init(applicationContext)
        super.onCreate(savedInstanceState)

        // Request mic permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermission.launch(Manifest.permission.RECORD_AUDIO)
        }

        // Build DB off main thread to avoid ANR (Room.build() is blocking)
        lifecycleScope.launch(Dispatchers.IO) {
            val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "sound-amplifier-db")
                .addMigrations(MIGRATION_2_3, MIGRATION_3_4)
                .fallbackToDestructiveMigration()
                .build()
            val repository = ProfileRepository(db.audiogramDao())

            withContext(Dispatchers.Main) {
                profileRepository = repository
                authViewModel = ViewModelProvider(this@MainActivity, object : ViewModelProvider.Factory {
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        @Suppress("UNCHECKED_CAST")
                        return AuthViewModel(repository, db.customPresetDao()) as T
                    }
                })[AuthViewModel::class.java]

                amplifierViewModel = ViewModelProvider(this@MainActivity, object : ViewModelProvider.Factory {
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        @Suppress("UNCHECKED_CAST")
                        return AmplifierViewModel(repository, db.customPresetDao(), applicationContext) as T
                    }
                })[AmplifierViewModel::class.java]

                audiogramViewModel = ViewModelProvider(this@MainActivity, object : ViewModelProvider.Factory {
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        @Suppress("UNCHECKED_CAST")
                        return AudiogramViewModel(profileRepository, applicationContext) as T
                    }
                })[AudiogramViewModel::class.java]

                setContent {
                    val followSystem by ThemeManager.followSystem.collectAsState(initial = true)
                    val explicitDark by ThemeManager.explicitDark.collectAsState(initial = false)
                    val systemIsDark = isSystemInDarkTheme()
                    val isDarkMode = if (followSystem) systemIsDark else explicitDark
                    val authState by authViewModel.state.collectAsState()
                    SmartHearTheme(darkTheme = isDarkMode) {
                        val context = LocalContext.current
                        val navController = rememberNavController()
                        var hearingPromptSessionSkip by remember { mutableStateOf(false) }
                        var hearingPrefsEpoch by remember { mutableStateOf(0) }
                        var accountScopeNonce by remember { mutableStateOf(0) }
                        var savedProfileExists by remember { mutableStateOf(false) }

                        LaunchedEffect(accountScopeNonce, authState) {
                            val keyId = AccountLocalIds.localKey(this@MainActivity)
                            savedProfileExists = withContext(Dispatchers.IO) {
                                profileRepository.getLatestForAccount(keyId) != null
                            }
                            val shouldRefresh = authState is AuthState.LoggedIn ||
                                authState is AuthState.LoggedOut ||
                                accountScopeNonce > 0
                            if (shouldRefresh) {
                                amplifierViewModel.refreshAccountScope(this@MainActivity)
                            }
                        }

                        LaunchedEffect(navController, accountScopeNonce, authState) {
                            snapshotFlow { navController.currentDestination?.route }
                                .distinctUntilChanged()
                                .filter { it == "home" }
                                .collect {
                                    val keyId = AccountLocalIds.localKey(this@MainActivity)
                                    savedProfileExists = withContext(Dispatchers.IO) {
                                        profileRepository.getLatestForAccount(keyId) != null
                                    }
                                }
                        }

                        val exitToWelcome: () -> Unit = {
                            authViewModel.logout()
                            ThemeManager.clearGuestMode(this@MainActivity)
                            accountScopeNonce++
                            navController.navigate("welcome") {
                                popUpTo(navController.graph.id) { inclusive = true }
                                launchSingleTop = true
                            }
                        }

                        val startRoute = remember {
                            if (FirebaseAuth.getInstance().currentUser != null) "home" else "welcome"
                        }

                        val googleSignInClient = remember {
                            val webId = context.getString(R.string.default_web_client_id)
                            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                                .requestIdToken(webId)
                                .requestEmail()
                                .requestProfile()
                                .build()
                            GoogleSignIn.getClient(this@MainActivity, gso)
                        }
                        val googleSignInLauncher = rememberLauncherForActivityResult(
                            ActivityResultContracts.StartActivityForResult()
                        ) { result ->
                            if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
                            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                            try {
                                val account = task.getResult(ApiException::class.java)
                                authViewModel.onGoogleSignInResult(account.idToken, null)
                            } catch (e: ApiException) {
                                authViewModel.onGoogleSignInResult(
                                    null,
                                    e.message ?: "Google sign-in failed"
                                )
                            }
                        }

                        NavHost(navController = navController, startDestination = startRoute) {
                            composable("collect_phone") {
                                PhoneCaptureScreen(
                                    isDarkMode = isDarkMode,
                                    onThemeToggle = { ThemeManager.toggle(this@MainActivity, isDarkMode) },
                                    onContinue = { phone ->
                                        authViewModel.saveUserPhoneNumber(
                                            phone,
                                            onInvalid = { toastInvalidPhone(context) },
                                            onError = { msg ->
                                                Toast.makeText(
                                                    context,
                                                    msg,
                                                    Toast.LENGTH_LONG,
                                                ).show()
                                            },
                                        )
                                    },
                                    onSignOut = exitToWelcome,
                                )
                            }

                            composable("welcome") {
                                WelcomeScreen(
                                    isDarkMode = isDarkMode,
                                    onThemeToggle = { ThemeManager.toggle(this@MainActivity, isDarkMode) },
                                    onLoginGoogle = {
                                        val webId = context.getString(R.string.default_web_client_id)
                                        if (webId.isBlank() || webId.contains("REPLACE_WITH_FIREBASE")) {
                                            Toast.makeText(
                                                context,
                                                context.getString(R.string.google_sign_in_not_configured),
                                                Toast.LENGTH_LONG
                                            ).show()
                                        } else {
                                            googleSignInClient.signOut().addOnCompleteListener {
                                                val signInIntent = googleSignInClient.signInIntent
                                                googleSignInLauncher.launch(signInIntent)
                                            }
                                        }
                                    },
                                )
                            }

                            composable("home") {
                                key(accountScopeNonce) {
                                @Suppress("UNUSED_VARIABLE")
                                val _hearingPrefsTick = hearingPrefsEpoch
                                val accountId = AccountLocalIds.localKey(this@MainActivity)
                                val completed = HearingTestPreferences.isCompleted(this@MainActivity, accountId)
                                val dismissed = HearingTestPreferences.isDismissedForever(this@MainActivity, accountId)
                                val showPrompt = !savedProfileExists && !completed && !dismissed &&
                                    !hearingPromptSessionSkip
                                val profileActive = savedProfileExists || completed
                                HomeScreen(
                                    isDarkMode = isDarkMode,
                                    onThemeToggle = { ThemeManager.toggle(this@MainActivity, isDarkMode) },
                                    showHearingTestPrompt = showPrompt,
                                    hearingProfileActive = profileActive,
                                    onStartAudiogramTest = {
                                        audiogramViewModel.prepareRetake()
                                        navController.navigate("audiogram")
                                    },
                                    onSkipHearingPrompt = { hearingPromptSessionSkip = true },
                                    onDismissHearingPromptForever = {
                                        HearingTestPreferences.setDismissedForever(this@MainActivity, accountId)
                                        hearingPrefsEpoch++
                                    },
                                    onOpenAmplifier = { navController.navigate("amplifier") },
                                    onLogout = exitToWelcome,
                                )
                                }
                            }

                            composable("audiogram") {
                                val state by audiogramViewModel.uiState.collectAsState()
                                AudiogramScreen(
                                    uiState = state,
                                    onStart = { audiogramViewModel.startTest() },
                                    onHeard = { audiogramViewModel.userHeard() },
                                    onCannotHear = { audiogramViewModel.userCannotHear() },
                                    onDismissInstruction = { audiogramViewModel.dismissInstruction() },
                                    onContinueTransition = { audiogramViewModel.continueAfterLeftEar() },
                                    onSaveAndApply = {
                                        lifecycleScope.launch {
                                            val s = audiogramViewModel.uiState.value
                                            val left = s.leftThresholds.map { it.toFloat() }
                                            val right = s.rightThresholds.map { it.toFloat() }
                                            withContext(Dispatchers.IO) {
                                                audiogramViewModel.persistAudiogram(left, right)
                                            }
                                            val preset =
                                                amplifierViewModel.buildMyHearingProfilePreset(left, right)
                                            amplifierViewModel.replaceMyHearingProfileAndApplyNow(preset)
                                            amplifierViewModel.loadLatestProfilePublic()
                                            HearingTestPreferences.setCompleted(
                                                this@MainActivity,
                                                AccountLocalIds.localKey(this@MainActivity),
                                            )
                                            Toast.makeText(
                                                this@MainActivity,
                                                getString(R.string.hearing_test_profile_applied),
                                                Toast.LENGTH_LONG
                                            ).show()
                                            navController.navigate("amplifier") {
                                                popUpTo("home")
                                            }
                                        }
                                    },
                                    onRetake = { audiogramViewModel.prepareRetake() },
                                )
                            }

                            composable("faq") {
                                FaqScreen(onBack = { navController.popBackStack() })
                            }

                            composable("settings") {
                                key(accountScopeNonce) {
                                var lastTested by remember { mutableStateOf<Long?>(null) }
                                LaunchedEffect(accountScopeNonce, authState) {
                                    lastTested = withContext(Dispatchers.IO) {
                                        val aid = AccountLocalIds.localKey(this@MainActivity)
                                        profileRepository.getLatestForAccount(aid)?.createdAt
                                    }
                                }
                                SettingsScreen(
                                    currentLanguageCode = LocaleManager.getSavedLanguageCode(this@MainActivity),
                                    onLanguageSelected = { code ->
                                        LocaleManager.setLanguage(this@MainActivity, code)
                                    },
                                    onBack = { navController.popBackStack() },
                                    lastTestedMillis = lastTested,
                                    onRetakeHearingTest = {
                                        audiogramViewModel.prepareRetake()
                                        navController.navigate("audiogram") {
                                            launchSingleTop = true
                                        }
                                    },
                                )
                                }
                            }

                            composable("profile") {
                                ProfileScreen(
                                    onBack = { navController.popBackStack() },
                                    onLogout = exitToWelcome,
                                    onNavigateLogin = {
                                        navController.navigate("welcome") {
                                            popUpTo(navController.graph.id) { inclusive = true }
                                            launchSingleTop = true
                                        }
                                    },
                                )
                            }

                            composable("amplifier") {
                                val state by amplifierViewModel.uiState.collectAsState()
                                val customPresets by amplifierViewModel.customPresets.collectAsState()
                                AmplifierScreen(
                                    uiState = state,
                                    onToggle = { amplifierViewModel.toggleAmplifier() },
                                    onBoostQuietSoundsChange = { amplifierViewModel.setBoostQuietSounds(it) },
                                    onMasterGainChange = { amplifierViewModel.setMasterGain(it) },
                                    onLowBoostChange = { amplifierViewModel.setLowBoost(it) },
                                    onHighBoostChange = { amplifierViewModel.setHighBoost(it) },
                                    onApplyPreset = { amplifierViewModel.applyPreset(it) },
                                    customPresets = customPresets,
                                    onApplyCustomPreset = { amplifierViewModel.applyCustomPreset(it) },
                                    onDeleteCustomPreset = { amplifierViewModel.deleteCustomPreset(it) },
                                    onSaveCurrentAsPreset = { amplifierViewModel.saveCurrentAsPreset(it) },
                                    toastMessages = amplifierViewModel.toasts,
                                    isDarkMode = isDarkMode,
                                    onThemeToggle = { ThemeManager.toggle(this@MainActivity, isDarkMode) },
                                    onNavigateHome = {
                                        navController.navigate("home") {
                                            launchSingleTop = true
                                        }
                                    },
                                    onNavigateProfile = { navController.navigate("profile") },
                                    onNavigateFaq = { navController.navigate("faq") },
                                    onNavigateSettings = { navController.navigate("settings") },
                                    onNavigateAudiogram = {
                                        audiogramViewModel.prepareRetake()
                                        navController.navigate("audiogram") {
                                            launchSingleTop = true
                                        }
                                    },
                                    onLogout = exitToWelcome,
                                    onResumeMicLabels = { amplifierViewModel.refreshMicDeviceLabels() }
                                )
                            }
                        }

                        LaunchedEffect(navController, authState) {
                            snapshotFlow {
                                navController.currentDestination?.route to
                                    (FirebaseAuth.getInstance().currentUser != null)
                            }
                                .distinctUntilChanged()
                                .collect { (route, loggedIn) ->
                                    if (route == null) return@collect
                                    if (!loggedIn && route == "home") {
                                        navController.navigate("welcome") {
                                            popUpTo("home") { inclusive = true }
                                            launchSingleTop = true
                                        }
                                    }
                                }
                        }

                        // React to auth state changes by navigating.
                        LaunchedEffect(authState) {
                            when (val s = authState) {
                                is AuthState.LoggedIn -> {
                                    ThemeManager.clearGuestMode(this@MainActivity)
                                    val dest = if (s.needsPhoneCapture) "collect_phone" else "home"
                                    if (navController.currentDestination?.route != dest) {
                                        navController.navigate(dest) {
                                            popUpTo(navController.graph.id) { inclusive = true }
                                            launchSingleTop = true
                                        }
                                    }
                                    launch {
                                        delay(900)
                                        amplifierViewModel.refreshAccountScope(this@MainActivity)
                                    }
                                }
                                else -> Unit
                            }
                        }
                    }
                }
            }
        }
    }
}

private val BrandPrimary = Color(0xFF7C5CBF)
private val BrandOnPrimary = Color.White
private val BrandSecondary = Color(0xFF9B7FD4)

@Composable
private fun SmartHearTheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = Color(0xFFD0BCFF),
            onPrimary = Color(0xFF381E72),
            primaryContainer = Color(0xFF4F378B),
            onPrimaryContainer = Color(0xFFEADDFF),
            secondary = Color(0xFFCCC2DC),
            onSecondary = Color(0xFF332D41),
            secondaryContainer = Color(0xFF4A4458),
            onSecondaryContainer = Color(0xFFE8DEF8),
            tertiary = Color(0xFFEFB8C8),
            background = Color(0xFF121218),
            surface = Color(0xFF1A1A22),
            surfaceVariant = Color(0xFF49454F),
            onBackground = Color(0xFFE6E1E5),
            onSurface = Color(0xFFE6E1E5),
            onSurfaceVariant = Color(0xFFCAC4D0),
            outline = Color(0xFF938F99),
            outlineVariant = Color(0xFF49454F),
        )
    } else {
        lightColorScheme(
            primary = BrandPrimary,
            onPrimary = BrandOnPrimary,
            primaryContainer = Color(0xFFE8E0FF),
            onPrimaryContainer = Color(0xFF3D2B5C),
            secondary = BrandSecondary,
            onSecondary = BrandOnPrimary,
            secondaryContainer = Color(0xFFF3EEFF),
            onSecondaryContainer = Color(0xFF3D2B5C),
            tertiary = Color(0xFFFFB86C),
            background = Color(0xFFF5F5F7),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFE7E0EC),
            onBackground = Color(0xFF11111A),
            onSurface = Color(0xFF11111A),
            onSurfaceVariant = Color(0xFF6B6B7A),
            outline = Color(0xFF7C5CBF),
            outlineVariant = Color(0xFFCAC4D0),
        )
    }
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
