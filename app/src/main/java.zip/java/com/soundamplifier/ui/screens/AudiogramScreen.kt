package com.soundamplifier.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.soundamplifier.R
import com.soundamplifier.data.AUDIOGRAM_FREQUENCIES
import com.soundamplifier.viewmodel.AudiogramViewModel
import com.soundamplifier.viewmodel.FrequencyTransitionInfo
import com.soundamplifier.viewmodel.HearingTestUiState
import com.soundamplifier.viewmodel.StepDirection
import com.soundamplifier.viewmodel.TestPhase
import kotlinx.coroutines.delay
import kotlin.math.log10

private val LeftEarColor = Color(0xFF1565C0)
private val RightEarColor = Color(0xFFC62828)

private const val INSTRUCTION_AUTO_DISMISS_MS = 6000L
private const val DOT_COUNT = 8

/** Overall 0..1 including sub-progress within the current frequency. */
fun overallTestProgress(ui: HearingTestUiState): Float {
    if (ui.phase != TestPhase.TESTING_LEFT && ui.phase != TestPhase.TESTING_RIGHT) return 0f
    val earBase = if (ui.phase == TestPhase.TESTING_LEFT) 0 else 6
    val cap = AudiogramViewModel.MAX_VOLUME_STEPS_PER_FREQ_FOR_UI.toFloat().coerceAtLeast(1f)
    val within = (ui.volumeStepCount / cap).coerceIn(0f, 0.92f)
    return ((earBase + ui.currentFrequencyIndex + within) / 12f).coerceIn(0f, 1f)
}

@Composable
fun AudiogramScreen(
    uiState: HearingTestUiState,
    onStart: () -> Unit,
    onHeard: () -> Unit,
    onCannotHear: () -> Unit,
    onContinueTransition: () -> Unit,
    onSaveAndApply: () -> Unit,
    onRetake: () -> Unit,
    onDismissInstruction: () -> Unit = {},
) {
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        when (uiState.phase) {
            TestPhase.INTRO -> IntroContent(onStart)
            TestPhase.TESTING_LEFT,
            TestPhase.TESTING_RIGHT,
            -> TestingContent(
                uiState = uiState,
                onHeard = onHeard,
                onCannotHear = onCannotHear,
                onDismissInstruction = onDismissInstruction,
            )
            TestPhase.TRANSITION -> TransitionContent(uiState, onContinueTransition)
            TestPhase.COMPLETE -> ResultsContent(uiState, onSaveAndApply, onRetake)
        }
    }
}

@Composable
private fun IntroContent(onStart: () -> Unit) {
    Text(
        text = stringResource(R.string.hearing_test_title),
        style = MaterialTheme.typography.headlineMedium,
        color = MaterialTheme.colorScheme.onBackground
    )
    Spacer(modifier = Modifier.height(12.dp))
    Text(
        text = stringResource(R.string.hearing_test_intro),
        style = MaterialTheme.typography.bodyMedium,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(8.dp))
    Text(
        text = stringResource(R.string.hearing_test_time),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary
    )
    Spacer(modifier = Modifier.height(24.dp))
    Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.hearing_test_start))
    }
}

@Composable
private fun TestingContent(
    uiState: HearingTestUiState,
    onHeard: () -> Unit,
    onCannotHear: () -> Unit,
    onDismissInstruction: () -> Unit,
) {
    val leftPhase = uiState.phase == TestPhase.TESTING_LEFT
    val earColor = if (leftPhase) LeftEarColor else RightEarColor
    val earShort = if (leftPhase) {
        stringResource(R.string.hearing_test_left_ear_short)
    } else {
        stringResource(R.string.hearing_test_right_ear_short)
    }

    val tapScale = remember { Animatable(1f) }
    LaunchedEffect(uiState.interactionEpoch) {
        if (uiState.interactionEpoch > 0) {
            tapScale.snapTo(0.92f)
            tapScale.animateTo(
                1f,
                spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
            )
        }
    }

    LaunchedEffect(uiState.showInstructionOverlay) {
        if (!uiState.showInstructionOverlay) return@LaunchedEffect
        delay(INSTRUCTION_AUTO_DISMISS_MS)
        onDismissInstruction()
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    transformOrigin = TransformOrigin.Center
                    scaleX = tapScale.value
                    scaleY = tapScale.value
                },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            RowEarIndicator(
                earLabel = if (leftPhase) stringResource(R.string.hearing_test_left_ear)
                else stringResource(R.string.hearing_test_right_ear),
                color = earColor,
            )

            Spacer(modifier = Modifier.height(12.dp))
            val primaryProgress by animateFloatAsState(
                targetValue = overallTestProgress(uiState),
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "progress",
            )
            val segmentFill by animateFloatAsState(
                targetValue = run {
                    val cap = AudiogramViewModel.MAX_VOLUME_STEPS_PER_FREQ_FOR_UI.toFloat().coerceAtLeast(1f)
                    (uiState.volumeStepCount / cap).coerceIn(0f, 1f)
                },
                animationSpec = tween(220),
                label = "segFill",
            )
            Text(
                text = stringResource(
                    R.string.hearing_test_status_ear_freq,
                    earShort,
                    AUDIOGRAM_FREQUENCIES[uiState.currentFrequencyIndex],
                ),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = statusSubtitle(uiState),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = stringResource(R.string.hearing_test_freq_progress, uiState.currentFrequencyIndex + 1),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(6.dp))
            TestProgressBar(
                overallProgress = primaryProgress,
                color = earColor,
            )
            Spacer(modifier = Modifier.height(4.dp))
            SegmentedFrequencyProgress(
                phase = uiState.phase,
                frequencyIndex = uiState.currentFrequencyIndex,
                segmentFill = segmentFill,
                color = earColor,
            )

            Spacer(modifier = Modifier.height(12.dp))
            VolumeStepDots(
                volumeStepCount = uiState.volumeStepCount,
                activeColor = earColor,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.hearing_test_step_n, uiState.volumeStepCount + 1),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.outline,
            )

            Spacer(modifier = Modifier.height(16.dp))
            val hz = AUDIOGRAM_FREQUENCIES[uiState.currentFrequencyIndex]
            Text(
                text = "$hz Hz",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary,
            )

            Spacer(modifier = Modifier.height(24.dp))

            val infinite = rememberInfiniteTransition(label = "tone")
            val pulse by infinite.animateFloat(
                initialValue = 0.88f,
                targetValue = 1.12f,
                animationSpec = infiniteRepeatable(
                    animation = tween(650),
                    repeatMode = RepeatMode.Reverse,
                ),
                label = "pulse",
            )
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .graphicsLayer {
                        transformOrigin = TransformOrigin.Center
                        scaleX = pulse
                        scaleY = pulse
                    }
                    .background(
                        if (uiState.isPlayingTone) earColor.copy(alpha = 0.25f) else Color.Transparent,
                        CircleShape,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (uiState.isPlayingTone) Icons.Rounded.VolumeUp else Icons.Rounded.Hearing,
                    contentDescription = null,
                    modifier = Modifier.size(44.dp),
                    tint = if (uiState.isPlayingTone) earColor else MaterialTheme.colorScheme.outline,
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (uiState.isPlayingTone) {
                    stringResource(R.string.hearing_test_status_playing)
                } else {
                    stringResource(R.string.hearing_test_status_waiting)
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )

            Spacer(modifier = Modifier.height(28.dp))

            val enabled = uiState.responseEnabled && !uiState.isPlayingTone && uiState.frequencyTransition == null
            Button(
                onClick = onHeard,
                enabled = enabled,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2E7D32),
                    disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(stringResource(R.string.hearing_test_i_hear))
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onCannotHear,
                enabled = enabled,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFB71C1C),
                    disabledContentColor = MaterialTheme.colorScheme.outline,
                ),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(stringResource(R.string.hearing_test_i_cant))
                }
            }
        }

        uiState.frequencyTransition?.let { info ->
            FrequencyTransitionOverlay(info = info)
        }

        AnimatedVisibility(
            visible = uiState.showInstructionOverlay,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
        ) {
            InstructionOverlayCard(
                onDismiss = onDismissInstruction,
                modifier = Modifier.matchParentSize(),
            )
        }
    }
}

@Composable
private fun statusSubtitle(ui: HearingTestUiState): String {
    val transition = ui.frequencyTransition
    if (transition != null) {
        return stringResource(R.string.hearing_test_status_moving_to_hz, transition.nextHz)
    }
    if (ui.isPlayingTone) {
        return stringResource(R.string.hearing_test_status_playing)
    }
    return when (ui.lastDirection) {
        StepDirection.DOWN -> stringResource(R.string.hearing_test_status_getting_quieter)
        StepDirection.UP -> stringResource(R.string.hearing_test_status_listen_louder)
        null -> stringResource(R.string.hearing_test_status_can_you_hear)
    }
}

@Composable
private fun TestProgressBar(
    overallProgress: Float,
    color: Color,
) {
    LinearProgressIndicator(
        progress = { overallProgress.coerceIn(0f, 1f) },
        modifier = Modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(MaterialTheme.shapes.small),
        color = color,
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
        strokeCap = StrokeCap.Round,
    )
}

/** Twelve slots (6 per ear): completed slots solid; current slot fills by [segmentFill] with each tap. */
@Composable
private fun SegmentedFrequencyProgress(
    phase: TestPhase,
    frequencyIndex: Int,
    segmentFill: Float,
    color: Color,
) {
    val earBase = if (phase == TestPhase.TESTING_LEFT) 0 else 6
    val currentSlot = (earBase + frequencyIndex).coerceIn(0, 11)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(6.dp),
    ) {
        repeat(12) { slot ->
            val completed = slot < currentSlot
            val current = slot == currentSlot
            val frac = when {
                completed -> 1f
                current -> segmentFill.coerceIn(0.04f, 1f)
                else -> 0f
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(horizontal = 1.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            ) {
                if (frac > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(frac)
                            .background(
                                if (current) color else color.copy(alpha = 0.45f),
                            ),
                    )
                }
            }
        }
    }
}

@Composable
private fun VolumeStepDots(volumeStepCount: Int, activeColor: Color) {
    val filled = volumeStepCount.coerceIn(0, DOT_COUNT)
    Row(
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxWidth()
    ) {
        repeat(DOT_COUNT) { i ->
            val on = i < filled
            Box(
                modifier = Modifier
                    .padding(horizontal = 3.dp)
                    .size(if (on) 10.dp else 8.dp)
                    .clip(CircleShape)
                    .background(
                        if (on) activeColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                    )
            )
        }
    }
}

@Composable
private fun FrequencyTransitionOverlay(info: FrequencyTransitionInfo) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(R.string.hearing_test_freq_done_line, info.completedHz),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.hearing_test_transition_threshold_db, info.thresholdDb),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = stringResource(R.string.hearing_test_status_moving_to_hz, info.nextHz),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun InstructionOverlayCard(onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.4f)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = MaterialTheme.shapes.large,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(R.string.hearing_test_instruction_overlay),
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.hearing_test_got_it))
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.hearing_test_skip_tip))
                }
            }
        }
    }
}

@Composable
private fun RowEarIndicator(earLabel: String, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.12f), MaterialTheme.shapes.medium)
            .padding(vertical = 12.dp, horizontal = 16.dp)
    ) {
        Icon(
            Icons.Rounded.Hearing,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = earLabel,
            style = MaterialTheme.typography.titleMedium,
            color = color,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun TransitionContent(uiState: HearingTestUiState, onContinue: () -> Unit) {
    val avgLeft = uiState.leftThresholds
        .filter { it >= 0 }
        .takeIf { it.size == 6 }
        ?.average()
        ?.toFloat()
        ?: 0f

    Text(
        text = stringResource(R.string.hearing_test_left_complete),
        style = MaterialTheme.typography.headlineSmall,
        color = LeftEarColor,
        textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(8.dp))
    Text(
        text = stringResource(R.string.hearing_test_switching_right_ear),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(12.dp))
    Text(
        text = stringResource(R.string.hearing_test_left_avg, "%.0f".format(avgLeft)),
        style = MaterialTheme.typography.bodyLarge,
        textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(16.dp))
    Text(
        text = stringResource(R.string.hearing_test_transition_body),
        style = MaterialTheme.typography.bodyMedium,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(24.dp))
    Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.hearing_test_continue))
    }
}

@Composable
private fun ResultsContent(
    uiState: HearingTestUiState,
    onSaveAndApply: () -> Unit,
    onRetake: () -> Unit,
) {
    val leftF = uiState.leftThresholds.map { it.toFloat() }
    val rightF = uiState.rightThresholds.map { it.toFloat() }
    val bilateralAvg = (leftF + rightF).average().toFloat()
    val interpRes = when {
        bilateralAvg < 25f -> R.string.hearing_test_normal
        bilateralAvg < 40f -> R.string.hearing_test_mild
        bilateralAvg < 55f -> R.string.hearing_test_moderate
        bilateralAvg < 70f -> R.string.hearing_test_mod_severe
        else -> R.string.hearing_test_severe
    }
    val avgLeft = leftF.average().toFloat()
    val avgRight = rightF.average().toFloat()

    Text(
        text = stringResource(R.string.hearing_test_complete),
        style = MaterialTheme.typography.headlineMedium
    )
    Spacer(modifier = Modifier.height(8.dp))
    Text(
        text = stringResource(R.string.hearing_test_complete_status_line),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(16.dp))

    ResultsAudiogramChart(
        leftThresholds = leftF,
        rightThresholds = rightF,
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
    )

    Spacer(modifier = Modifier.height(16.dp))
    Text(
        text = stringResource(
            R.string.hearing_test_result_avgs,
            "%.0f".format(avgLeft),
            "%.0f".format(avgRight)
        ),
        style = MaterialTheme.typography.bodyMedium,
        textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(8.dp))
    Text(
        text = stringResource(interpRes),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(24.dp))
    Button(onClick = onSaveAndApply, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.hearing_test_save))
    }
    Spacer(modifier = Modifier.height(12.dp))
    OutlinedButton(onClick = onRetake, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.hearing_test_retake))
    }
}

@Composable
private fun ResultsAudiogramChart(
    leftThresholds: List<Float>,
    rightThresholds: List<Float>,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val n = AUDIOGRAM_FREQUENCIES.size
        val maxDb = 80f
        drawAudiogramGrid(w, h, n, maxDb)
        plotEarLine(leftThresholds, LeftEarColor, w, h, n, maxDb)
        plotEarLine(rightThresholds, RightEarColor, w, h, n, maxDb)
    }
}

private fun DrawScope.drawAudiogramGrid(w: Float, h: Float, freqCount: Int, maxDb: Float) {
    val grid = Color.LightGray.copy(alpha = 0.7f)
    val steps = 5
    for (i in 0..steps) {
        val db = maxDb * i / steps
        val y = h * (db / maxDb)
        drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
    }
    for (i in 0 until freqCount) {
        val x = freqX(i, freqCount, w)
        drawLine(grid, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
    }
}

private fun freqX(i: Int, n: Int, w: Float): Float {
    if (n <= 1) return w / 2f
    val f = AUDIOGRAM_FREQUENCIES[i].toFloat()
    val f0 = AUDIOGRAM_FREQUENCIES.first().toFloat()
    val f1 = AUDIOGRAM_FREQUENCIES.last().toFloat()
    val t = (log10(f / f0) / log10(f1 / f0)).coerceIn(0f, 1f)
    return t * w
}

private fun DrawScope.plotEarLine(
    thresholds: List<Float>,
    color: Color,
    w: Float,
    h: Float,
    freqCount: Int,
    maxDb: Float,
) {
    if (thresholds.size < freqCount) return
    val points = thresholds.mapIndexed { i, db ->
        Offset(
            x = freqX(i, freqCount, w),
            y = h * (db.coerceIn(0f, maxDb) / maxDb)
        )
    }
    for (i in 0 until points.size - 1) {
        drawLine(color, points[i], points[i + 1], strokeWidth = 3f)
    }
    points.forEach { drawCircle(color, radius = 7f, center = it) }
}





