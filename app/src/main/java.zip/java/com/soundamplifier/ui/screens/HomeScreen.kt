package com.soundamplifier.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import com.google.firebase.auth.FirebaseAuth
import com.soundamplifier.R

@Composable
fun HomeScreen(
    isDarkMode: Boolean = false,
    onThemeToggle: () -> Unit = {},
    showHearingTestPrompt: Boolean = false,
    hearingProfileActive: Boolean = false,
    onStartAudiogramTest: () -> Unit,
    onSkipHearingPrompt: () -> Unit = {},
    onDismissHearingPromptForever: () -> Unit = {},
    onOpenAmplifier: () -> Unit,
    onLogout: () -> Unit = {},
) {
    val firebaseAuth = remember { FirebaseAuth.getInstance() }
    var firebaseUser by remember { mutableStateOf(firebaseAuth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { firebaseUser = it.currentUser }
        firebaseAuth.addAuthStateListener(listener)
        onDispose { firebaseAuth.removeAuthStateListener(listener) }
    }
    val accountActionLabel = if (firebaseUser != null) {
        stringResource(R.string.profile_logout)
    } else {
        stringResource(R.string.nav_sign_in_switch_account)
    }

    val scheme = MaterialTheme.colorScheme
    val isLightBg = scheme.background.luminance() > 0.5f
    val blobPurpleAlpha = if (isLightBg) 0.15f else 0.28f
    val blobLavenderAlpha = if (isLightBg) 0.20f else 0.22f
    val floatTint1 = scheme.primary.copy(alpha = if (isLightBg) 0.13f else 0.20f)
    val floatTint2 = Color(0xFF34A853).copy(alpha = if (isLightBg) 0.13f else 0.18f)
    val floatTint3 = scheme.secondary.copy(alpha = if (isLightBg) 0.10f else 0.16f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background)
    ) {
        Box(
            modifier = Modifier
                .size(320.dp)
                .offset(x = 220.dp, y = (-80).dp)
                .clip(CircleShape)
                .blur(80.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            scheme.primary.copy(alpha = blobPurpleAlpha),
                            Color.Transparent
                        ),
                        radius = 380f,
                        tileMode = TileMode.Clamp
                    )
                )
        )
        Box(
            modifier = Modifier
                .size(360.dp)
                .offset(x = (-140).dp, y = 560.dp)
                .clip(CircleShape)
                .blur(92.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            scheme.secondary.copy(alpha = blobLavenderAlpha),
                            Color.Transparent
                        ),
                        radius = 420f,
                        tileMode = TileMode.Clamp
                    )
                )
        )

        FrostedFloatCircle(
            sizeDp = 40,
            color = floatTint1,
            borderAlpha = if (isLightBg) 0.45f else 0.28f,
            modifier = Modifier.offset(x = 26.dp, y = 92.dp)
        )
        FrostedFloatCircle(
            sizeDp = 70,
            color = floatTint2,
            borderAlpha = if (isLightBg) 0.45f else 0.28f,
            modifier = Modifier.offset(x = 308.dp, y = 210.dp)
        )
        FrostedFloatCircle(
            sizeDp = 100,
            color = floatTint3,
            borderAlpha = if (isLightBg) 0.45f else 0.28f,
            modifier = Modifier.offset(x = 286.dp, y = 630.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
        val unbounded = FontFamily(
            Font(
                googleFont = GoogleFont("Unbounded"),
                fontProvider = GoogleFont.Provider(
                    providerAuthority = "com.google.android.gms.fonts",
                    providerPackage = "com.google.android.gms",
                    certificates = R.array.com_google_android_gms_fonts_certs
                ),
                weight = FontWeight.Bold
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            IconButton(onClick = onThemeToggle) {
                Icon(
                    imageVector = if (isDarkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                    contentDescription = if (isDarkMode) {
                        stringResource(R.string.theme_light_mode)
                    } else {
                        stringResource(R.string.theme_dark_mode)
                    },
                    tint = scheme.onSurface,
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val glassShape = RoundedCornerShape(24.dp)
        val glassBg = scheme.surface.copy(alpha = if (isLightBg) 0.50f else 0.42f)
        val glassBorder = scheme.outline.copy(alpha = if (isLightBg) 0.35f else 0.28f)
        val shadowColor = if (isLightBg) Color(0x0F000000) else Color(0x40000000)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(
                    elevation = 32.dp,
                    shape = glassShape,
                    ambientColor = shadowColor,
                    spotColor = shadowColor
                )
                .clip(glassShape)
                .background(glassBg)
                .border(1.dp, glassBorder, glassShape)
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val logoBackdrop = colorResource(
                if (isLightBg) R.color.logo_backdrop_light else R.color.logo_backdrop_dark
            )
            Box(
                modifier = Modifier
                    .size(108.dp)
                    .clip(CircleShape)
                    .background(logoBackdrop),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = stringResource(R.string.cd_app_logo),
                    modifier = Modifier.fillMaxSize(0.76f),
                    contentScale = ContentScale.Fit,
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // KEEP HEADING EXACTLY (Unbounded Bold)
            Text(
                text = stringResource(R.string.amplifier_brand),
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontFamily = unbounded,
                    fontWeight = FontWeight.Bold
                ),
                textAlign = TextAlign.Center,
                color = scheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = stringResource(R.string.home_tagline),
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        if (showHearingTestPrompt) {
            val bannerShape = RoundedCornerShape(20.dp)
            val bannerShadow = if (isLightBg) Color(0x14000000) else Color(0x28000000)
            val g0 = scheme.secondaryContainer.copy(alpha = if (isLightBg) 1f else 0.55f)
            val g1 = scheme.primaryContainer.copy(alpha = if (isLightBg) 1f else 0.50f)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, bannerShape, ambientColor = bannerShadow, spotColor = bannerShadow)
                    .clip(bannerShape)
                    .background(Brush.horizontalGradient(colors = listOf(g0, g1)))
                    .border(1.dp, scheme.outline.copy(alpha = 0.35f), bannerShape)
                    .padding(18.dp)
            ) {
                Text(
                    text = stringResource(R.string.home_test_prompt),
                    style = MaterialTheme.typography.titleSmall,
                    color = scheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(12.dp))
                GradientPillButton(
                    text = stringResource(R.string.hearing_test_start),
                    onClick = onStartAudiogramTest,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = onSkipHearingPrompt) {
                        Text(
                            stringResource(R.string.home_test_prompt_skip),
                            color = scheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    TextButton(onClick = onDismissHearingPromptForever) {
                        Text(
                            stringResource(R.string.home_test_prompt_dismiss),
                            color = scheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        } else if (hearingProfileActive) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                val successColor = if (isLightBg) Color(0xFF2E7D32) else Color(0xFF81C784)
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = successColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = stringResource(R.string.home_test_active),
                    style = MaterialTheme.typography.bodyMedium,
                    color = successColor
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Primary purple gradient — open amplifier
        GradientPillButton(
            text = stringResource(R.string.home_open_amplifier),
            onClick = onOpenAmplifier,
            modifier = Modifier.fillMaxWidth(),
            isLightBg = isLightBg,
        )

        Spacer(modifier = Modifier.height(14.dp))

        FrostedPillButton(
            text = stringResource(R.string.home_take_test),
            onClick = onStartAudiogramTest,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.weight(1f))

        TextButton(
            onClick = onLogout,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = accountActionLabel,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.error
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        // Tip banner (frosted lavender tint)
        val tipShape = RoundedCornerShape(18.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(tipShape)
                .background(scheme.secondaryContainer.copy(alpha = if (isLightBg) 0.40f else 0.35f))
                .border(1.dp, scheme.outline.copy(alpha = if (isLightBg) 0.35f else 0.25f), tipShape)
                .padding(14.dp)
        ) {
            Text(
                text = stringResource(R.string.home_tip),
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSecondaryContainer,
                textAlign = TextAlign.Start
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
private fun FrostedFloatCircle(
    sizeDp: Int,
    color: Color,
    borderAlpha: Float,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = borderAlpha),
                CircleShape
            )
    )
}

@Composable
private fun GradientPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isLightBg: Boolean = true,
) {
    val scheme = MaterialTheme.colorScheme
    val c0 = scheme.primary
    val c1 = scheme.secondary
    val shadowTint = scheme.primary.copy(alpha = if (isLightBg) 0.30f else 0.45f)
    val shape = RoundedCornerShape(24.dp)
    Button(
        onClick = onClick,
        modifier = modifier
            .height(48.dp)
            .shadow(
                elevation = 16.dp,
                shape = shape,
                ambientColor = shadowTint,
                spotColor = shadowTint
            ),
        shape = shape,
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        contentPadding = PaddingValues(0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(colors = listOf(c0, c1))
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                color = scheme.onPrimary,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
private fun FrostedPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingContent: (@Composable RowScope.() -> Unit)? = null
) {
    val scheme = MaterialTheme.colorScheme
    val isLight = scheme.background.luminance() > 0.5f
    val shape = RoundedCornerShape(24.dp)
    val fill = scheme.surface.copy(alpha = if (isLight) 0.40f else 0.28f)
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = shape,
        border = androidx.compose.foundation.BorderStroke(1.dp, scheme.outline.copy(alpha = 0.35f)),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = fill)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (leadingContent != null) {
                leadingContent()
                Spacer(modifier = Modifier.width(10.dp))
            }
            Text(text = text, color = scheme.primary, style = MaterialTheme.typography.titleMedium)
        }
    }
}
