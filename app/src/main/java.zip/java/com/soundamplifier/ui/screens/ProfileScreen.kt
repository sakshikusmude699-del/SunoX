package com.soundamplifier.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.soundamplifier.R
import com.soundamplifier.data.AUDIOGRAM_FREQUENCIES
import com.soundamplifier.data.FirestoreUserRepository
import com.soundamplifier.data.normalizeFirestoreEarField
import com.soundamplifier.ui.LocaleManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val PrimaryPurple = Color(0xFF7C5CBF)
private val FrostedBorderLight = Color(0x26000000)
private val LogoutRed = Color(0xFFE53935)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onBack: () -> Unit,
    onLogout: () -> Unit,
    onNavigateLogin: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val auth = remember { FirebaseAuth.getInstance() }
    var firebaseUser by remember { mutableStateOf(auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { firebaseUser = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    var displayNameDraft by remember(firebaseUser?.uid, firebaseUser?.displayName) {
        mutableStateOf(firebaseUser?.displayName.orEmpty())
    }

    val firestoreRepo = remember { FirestoreUserRepository() }
    var audiograms by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    var audiogramsLoading by remember { mutableStateOf(false) }

    LaunchedEffect(firebaseUser?.uid) {
        val uid = firebaseUser?.uid ?: return@LaunchedEffect
        audiogramsLoading = true
        audiograms = firestoreRepo.getAllAudiograms(uid)
        audiogramsLoading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.profile_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = stringResource(R.string.nav_back),
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = if (firebaseUser == null) Arrangement.Center else Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (firebaseUser == null) {
                Text(
                    text = stringResource(R.string.profile_guest_message),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 8.dp),
                )
                Spacer(modifier = Modifier.height(24.dp))
                OutlinedButton(onClick = onNavigateLogin) {
                    Text(stringResource(R.string.profile_login))
                }
            } else {
                val signedInUser = firebaseUser!!
                UserInfoCard(
                    displayNameDraft = displayNameDraft,
                    onDisplayNameChange = { displayNameDraft = it },
                    phoneText = signedInUser.phoneNumber
                        ?: stringResource(R.string.profile_not_linked),
                    emailText = signedInUser.email
                        ?: stringResource(R.string.profile_not_linked),
                    onSaveName = {
                        scope.launch {
                            val user = auth.currentUser ?: return@launch
                            try {
                                val trimmed = displayNameDraft.trim()
                                val request = UserProfileChangeRequest.Builder()
                                    .setDisplayName(trimmed.takeIf { it.isNotEmpty() })
                                    .build()
                                user.updateProfile(request).await()
                                user.reload().await()
                                val updated = auth.currentUser ?: user
                                val lang = LocaleManager.getSavedLanguageCode(context)
                                firestoreRepo.createOrUpdateUserProfile(updated, lang)
                                firebaseUser = updated
                                displayNameDraft = updated.displayName.orEmpty()
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.profile_name_updated),
                                    Toast.LENGTH_SHORT,
                                ).show()
                            } catch (e: Exception) {
                                Toast.makeText(
                                    context,
                                    e.message ?: "Update failed",
                                    Toast.LENGTH_SHORT,
                                ).show()
                            }
                        }
                    },
                )
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = stringResource(R.string.profile_hearing_profiles),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp,
                        letterSpacing = 0.8.sp,
                        fontWeight = FontWeight.Medium,
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(12.dp))
                when {
                    audiogramsLoading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f, fill = false)
                                .height(120.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator(color = PrimaryPurple)
                        }
                    }
                    audiograms.isEmpty() -> {
                        Text(
                            text = stringResource(R.string.profile_no_audiograms),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    else -> {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f, fill = true),
                        ) {
                            itemsIndexed(
                                audiograms,
                                key = { _, doc ->
                                    "${doc["createdAt"]}_${doc["isActive"]}"
                                },
                            ) { _, doc ->
                                AudiogramSummaryCard(doc = doc)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedButton(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = LogoutRed),
                ) {
                    Text(stringResource(R.string.profile_logout))
                }
            }
        }
    }
}

@Composable
private fun UserInfoCard(
    displayNameDraft: String,
    onDisplayNameChange: (String) -> Unit,
    phoneText: String,
    emailText: String,
    onSaveName: () -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    val isLightTheme = MaterialTheme.colorScheme.background.luminance() > 0.5f
    val frostBg =
        if (isLightTheme) Color(0xB3FFFFFF)
        else MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.92f)
    val frostBorder =
        if (isLightTheme) FrostedBorderLight
        else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(frostBg)
            .border(1.dp, frostBorder, shape)
            .padding(16.dp),
    ) {
        Text(
            text = stringResource(R.string.profile_display_name),
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                letterSpacing = 0.8.sp,
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = displayNameDraft,
                onValueChange = onDisplayNameChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = {
                    Text(stringResource(R.string.profile_name_placeholder))
                },
            )
            IconButton(onClick = onSaveName) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = stringResource(R.string.done),
                    tint = PrimaryPurple,
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.profile_phone),
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                letterSpacing = 0.8.sp,
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = phoneText,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.profile_email),
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                letterSpacing = 0.8.sp,
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = emailText,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun AudiogramSummaryCard(doc: Map<String, Any>) {
    val createdRaw = doc["createdAt"]
    val dateStr = formatFirestoreDate(createdRaw)
    val leftAvg = earAverageDb(doc["leftEar"])
    val rightAvg = earAverageDb(doc["rightEar"])
    val isActive = doc["isActive"] as? Boolean == true
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), shape)
            .padding(14.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = dateStr,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
            )
            if (isActive) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(PrimaryPurple.copy(alpha = 0.18f))
                        .border(1.dp, PrimaryPurple.copy(alpha = 0.5f), RoundedCornerShape(999.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.profile_active_badge),
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryPurple,
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "${stringResource(R.string.profile_left_avg)}: ${leftAvg} dB",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = "${stringResource(R.string.profile_right_avg)}: ${rightAvg} dB",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun formatFirestoreDate(raw: Any?): String {
    val date: Date? = when (raw) {
        is Timestamp -> raw.toDate()
        is Date -> raw
        else -> null
    }
    if (date == null) return "—"
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    return sdf.format(date)
}

private fun earAverageDb(raw: Any?): Int {
    val map = normalizeFirestoreEarField(raw) ?: return 0
    val values = AUDIOGRAM_FREQUENCIES.map { hz -> map[hz.toString()] }.filterNotNull()
    if (values.isEmpty()) return 0
    return values.average().roundToInt()
}
