package com.soundamplifier

import android.app.Application
import com.soundamplifier.ui.LocaleManager

class SmartHearApp : Application() {
    override fun onCreate() {
        super.onCreate()
        LocaleManager.syncAppCompatLocales(this)
    }
}
